package hlt

import "math"

func DegToRad(d float64) float64{
	return d / 180 * math.Pi
}

func RadToDeg(r float64) float64{
	return r / math.Pi * 180
}
